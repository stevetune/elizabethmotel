<div class="footer">
		<div class="social-media-links">
			<a href="<?php echo $facebook_url; ?>">
				<i class="fab fa-facebook-f"></i>
			</a>
			<!-- <a href="<?php //echo $twitter_url; ?>">
				<i class="fab fa-twitter"></i>
			</a> -->
			<a href="<?php echo $instagram_url; ?>">
				<i class="fab fa-instagram"></i>
			</a>
			<a href="<?php echo $linkedin_url; ?>">
				<i class="fab fa-linkedin-in"></i>
			</a>
			<!-- <a href="<?php //echo $gplus_url; ?>">
				<i class="fab fa-google-plus-g"></i>
			</a>
			<a href="<?php //echo $pinterest_url; ?>">
				<i class="fab fa-pinterest-p"></i>
			</a> -->
		</div>
		<div class="footer-text">
			©Copyright 2022 <?php echo $property_title; ?>. All rights reserved.
		</div>
	</div>
