<div class="main-content-header">
			<div>
			    


    <h1><?php echo $hotel_title_header; ?></h1>
    <h2 class="white"><?php echo $hotel_title_subheader; ?></h2>
    <div class="rule"></div>





			</div>
			<p class="tagline"><?php echo $hotel_tagline; ?></p>
			<a target="_blank" class="clear-button" href="<?php echo $be_step1_full; ?>">BOOK TODAY</a>
		</div>