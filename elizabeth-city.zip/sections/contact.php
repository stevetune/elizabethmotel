<div class="in-page-link" id="contact"></div> 
	<div class="contact-section contact-section-bg">
		<div class="section">
			<h2 class="white">CONTACT</h2>
			<div class="contact-grid">
				<div class="map-container">
					<!-- <img class="map-pin" src="../images/pin@1x.png" /> -->
				</div>
				<div class="contact-info">
					<h3>Get in Touch</h3>
					<h2>ADDRESS</h2>
					<p><?php echo $address_line_1; ?></p>
					<p><?php echo $address_line_2; ?></p>
					<p><a href="<?php echo $directions_link; ?>">Get Directions</a></p>
					<h2>PHONE</h2>
					<p><a href="tel: <?php echo $phone; ?>"><?php echo $phone; ?></a></p>
					<!-- <h2>FAX</h2>
					<p><a href="#"><?php //echo $fax; ?></a></p> -->
					<h2>EMAIL</h2>
					<p><a href="mailto: <?php echo $email; ?>"><?php echo $email; ?></a></p>
				</div>
			</div>
		</div>
	</div>