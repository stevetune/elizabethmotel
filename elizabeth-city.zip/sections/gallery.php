<div class="in-page-link" id="gallery"></div> 
	<div class="gallery-section section">
		<h2 >GALLERY</h2>
		<div class="gallery-section-flex">
			<div class="gallery-image gallery-left">
				<div class="left-column-top"></div>
				<div class="left-column-bottom"></div>
			</div>
			<div class="gallery-image gallery-center">
				<img src="<?php echo './assets/images/'.$gallery_image_3; ?>" />
			</div>
			<div class="gallery-image gallery-right">
				<div class="left-column-top"></div>
				<div class="left-column-bottom"></div>
			
			</div>
		</div>
	</div>